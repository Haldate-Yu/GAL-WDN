#!/bin/bash
python plot_Taylor_diag.py --savepdf --wds anytown --smin 0. --smax 1.05
python plot_Taylor_diag.py --savepdf --wds ctown --smin 0.15 --smax 1.05
python plot_Taylor_diag.py --savepdf --wds richmond --smin 0.15 --smax 1.05
