#!/bin/bash
python plot_swarm_plot.py --drop 10 --obsrat 0.05 --ymax 0.003 --ymin 0.0024 --savepdf
python plot_swarm_plot.py --drop 15 --obsrat 0.8 --ymax .00008 --savepdf
