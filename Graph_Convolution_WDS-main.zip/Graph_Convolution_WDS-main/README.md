# Graph_Convolution_WDS
WDS GNNs for nodal pressure estimation
