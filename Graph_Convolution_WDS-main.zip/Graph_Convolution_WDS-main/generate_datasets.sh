#!/bin/bash

python generate_data.py --params db_anytown_doe_pumpfed_1
python generate_data.py --params db_ctown_doe_pumpfed_1
python generate_data.py --params db_richmond_doe_pumpfed_1